const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Create a transporter object using Gmail service
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'apka user gmail',
    pass: 'app specific password ', // Use app-specific password or environment variables
  },
});

// Handle POST request to /send endpoint
app.post('/send', (req, res) => {
  // Destructure recipient and message from request body
  const { recipient, message } = req.body;

  // Validate incoming request data
  if (!recipient || !message) {
    return res.status(400).json({ message: 'Recipient and message are required' });
  }

  // Log the incoming request for debugging purposes
  console.log('Sending email to:', recipient);
  console.log('Message:', message);

  // Set up mail options for sending the email
  const mailOptions = {
    from: 'your-email@gmail.com',
    to: recipient,
    subject: 'Voice-Based Email',
    text: message,
  };

  // Try sending the email
  try {
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        // Log the error and respond with a failure message
        console.error('Error sending email:', error);
        return res.status(500).json({ message: 'Failed to send email' });
      }

      // Log success and respond with a success message
      console.log('Email sent:', info);
      res.status(200).json({ message: 'Email sent successfully!' });
    });
  } catch (error) {
    // Catch unexpected errors
    console.error('Unexpected error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Start the server and listen on the specified port
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
