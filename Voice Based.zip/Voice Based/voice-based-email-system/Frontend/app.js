const recipientInput = document.getElementById('recipient');
const messageInput = document.getElementById('message');
const speakButton = document.getElementById('speak');
const sendButton = document.getElementById('send');
const recipientSpeakButton = document.getElementById('recipient-speak'); // New button for recipient input
const speakAssistButton = document.getElementById('speak-assist'); // Button for voice assistance

// Voice recognition setup
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';
recognition.interimResults = false;

let currentField = null; // To track which field is being dictated

// Start voice input for the message field
speakButton.addEventListener('click', () => {
  currentField = 'message';
  recognition.start();
});

// Start voice input for the recipient field
recipientSpeakButton.addEventListener('click', () => {
  currentField = 'recipient';
  recognition.start();
});

// Handle voice recognition results
recognition.addEventListener('result', (event) => {
  const transcript = event.results[0][0].transcript;

  if (currentField === 'recipient') {
    // Append the recognized text to the recipient field
    recipientInput.value += transcript;
  } else if (currentField === 'message') {
    // Append the recognized text to the message field
    messageInput.value += transcript;
  }
});

// Voice assistance to read field values
speakAssistButton.addEventListener('click', () => {
  const recipientText = recipientInput.value || "Recipient field is empty.";
  const messageText = messageInput.value || "Message field is empty.";
  
  const utterance = new SpeechSynthesisUtterance(
    `Recipient is ${recipientText}. Message is ${messageText}.`
  );
  
  utterance.lang = 'en-US';
  window.speechSynthesis.speak(utterance);
});

// Send email functionality
sendButton.addEventListener('click', async () => {
  const emailData = {
    recipient: recipientInput.value,
    message: messageInput.value,
  };

  const response = await fetch('http://localhost:3000/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(emailData),
  });

  const result = await response.json();
  alert(result.message);
});
